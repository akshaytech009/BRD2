package com.nucleus.dao;


import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



import com.nucleus.model.Customer;

@Repository
public class CustomerDAOImpl implements ICustomerDAO {
	final static Logger logger = Logger.getLogger(com.nucleus.dao.CustomerDAOImpl.class);
@Autowired
SessionFactory sessionfactory;
public void insert(Customer customer) {
	//System.out.println("\n pspspsppssppsps"+ customer.getCreatedBy() + customer.getCustomerName());
	customer.setRegistrationDate(new java.sql.Date(new Date().getTime()));
	
	//sessionfactory.openSession().persist(customer);
	sessionfactory.getCurrentSession().saveOrUpdate(customer);
//	sessionfactory.getCurrentSession().persist(customer);
}	

	public void delete(Customer customer) {
		
		
		sessionfactory.getCurrentSession().delete(customer);
     		
	}

	public Customer view(Customer customer) {
		int code= customer.getCustomerCode();
		System.out.println(code);
		Session session=sessionfactory.getCurrentSession();
	Customer c =(Customer)session.get(Customer.class,code); 
		return c;
	}

	public List<Customer> viewall() {
		
		Session session=sessionfactory.getCurrentSession();
		List<Customer> customerList = session.createQuery("from FinalBRDCustomer").list();
		return	customerList;
		
		
		//return null;
	}

	public Customer update(Customer customer) {
		
		int code=customer.getCustomerCode();
		Session session =sessionfactory.getCurrentSession();
		Customer c = (Customer) session.get(Customer.class,code);
		
		return c;
	}
	public void insert2(Customer customer)
	{
			//LocalDateTime.now();
		System.out.println("\n MODIFIED DATE DAO before:- "+ new java.sql.Date(new Date().getTime()));
		customer.setModifiedDate(new java.sql.Date(new Date().getTime()));
		System.out.println("\n MODIFIED DATE :- "+ customer.getModifiedDate());
		sessionfactory.getCurrentSession().saveOrUpdate(customer);
		
	}


	
	
}
