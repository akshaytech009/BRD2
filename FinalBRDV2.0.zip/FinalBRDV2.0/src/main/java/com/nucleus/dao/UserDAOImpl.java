package com.nucleus.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.model.User;

@Repository
public class UserDAOImpl implements  IUserDAO {

	@Autowired 
	SessionFactory sessionfactory;

	public void insert(User user) {
	sessionfactory.getCurrentSession().saveOrUpdate(user);	
	
	}
	
	
	
}
