package com.nucleus.dao;

import com.nucleus.model.User;

public interface IUserDAO {

	public void insert(User user);

	
	
}
