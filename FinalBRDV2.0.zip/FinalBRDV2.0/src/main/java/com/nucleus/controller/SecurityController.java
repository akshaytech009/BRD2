package com.nucleus.controller;





import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



import com.nucleus.model.User;
import com.nucleus.service.IUserService;
import com.nucleus.utility.PasswordEncoder;
@Controller
public class SecurityController {
	@Autowired
	IUserService userServiceimpl;
	
	final static Logger logger = Logger.getLogger(com.nucleus.controller.SecurityController.class);
	
	@RequestMapping(value="/loginpage")
	public String handlerMethod2()

	{
		return"Login";

	}
	@RequestMapping(value="/loginfailure")
	public ModelAndView handlerMethod3()
	
	{
		return new ModelAndView("Login");
		
	}
	@RequestMapping(value="/menu")
	public String handlerMethod4()

	{
		return "menu";

	}

	@RequestMapping("/adminPage")
	public String handlerMethod6( User user)

	{
		return "admin";

	}
	
	@RequestMapping("/userdone")
	public ModelAndView handlerMethod7(User user,ModelAndView modelAndView,RedirectAttributes redirect)

	{
		
		user.setEnabled(1);
		String hashPassword = PasswordEncoder.encodePassword(user.getPassword());
		user.setPassword(hashPassword);
		userServiceimpl.insert(user);
		
		String msg="Successfully Inserted";
		
		modelAndView.setViewName("redirect:adminPage");
	    redirect.addFlashAttribute("msg",msg);
		
		//return new ModelAndView("insert","msg",msg);
	    return modelAndView;
	}
	
	
}
