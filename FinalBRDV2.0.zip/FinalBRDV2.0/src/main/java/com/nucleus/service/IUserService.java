package com.nucleus.service;

import com.nucleus.model.User;

public interface IUserService {

	
	public void insert(User user);

	
}
